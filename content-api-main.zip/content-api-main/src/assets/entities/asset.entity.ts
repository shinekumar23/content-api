export class Asset {}
