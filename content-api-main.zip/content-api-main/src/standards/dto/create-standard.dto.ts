export class CreateStandardDto {
    uniqueid?: string;
    nativeid: string;
    description: string;
    isleaf: boolean;
    createdby: string;
    refstatustypeid: number;
    frameworkid: number;
  }
